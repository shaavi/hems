<div class="well card-footer">
  <p>©2023 Home Energy Management System
    <span class="float-right">Designed & Developed By: Lahiru, Ranga, Dhanushka, Anjalee, Manjula, Hazmath, Jeevanee, Rajmohan, Nuwan, Shavindi</span>
  </p>
</div>




</body>




<!-- Jquery script -->
<script src="assets/jquery.min.js"></script>
<script src="assets/bootstrap.min.js"></script>
<script src="assets/jquery.dataTables.min.js"></script>
<script src="assets/dataTables.bootstrap4.min.js"></script>
<script>
  $(document).ready(function() {
    $("#flash-msg").delay(7000).fadeOut("slow");
  });
  $(document).ready(function() {
    $('#example').DataTable();
  });
</script>

</html>